m=1
n=2
function ave=y(m,n)
